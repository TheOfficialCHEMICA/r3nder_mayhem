#include "app.h"
#include "ui/ui.h"
#include "hackrf/receiver.h"
#include "hackrf/transmitter.h"

class App_R3nderBurstJammer : public App {
public:
    void init() override {
        ui.title("App_R3nderBurstJammer - Init");
    }

    void run() override {
        ui.label("App_R3nderBurstJammer - Running");
    }

    void stop() override {
        ui.label("App_R3nderBurstJammer - Stopped");
    }
};

APP_FACTORY(App_R3nderBurstJammer);
