#include "app.h"
#include "ui/ui.h"
#include "hackrf/receiver.h"
#include "hackrf/transmitter.h"

class App_R3nderTriggerRadar : public App {
public:
    void init() override {
        ui.title("App_R3nderTriggerRadar - Init");
    }

    void run() override {
        ui.label("App_R3nderTriggerRadar - Running");
    }

    void stop() override {
        ui.label("App_R3nderTriggerRadar - Stopped");
    }
};

APP_FACTORY(App_R3nderTriggerRadar);
