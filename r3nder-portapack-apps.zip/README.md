# R3NDER OPS - Custom PortaPack Apps

This repo contains 8 custom SDR tools written for the HackRF PortaPack.

Each app is uniquely designed by r3nder for offensive RF experimentation.
