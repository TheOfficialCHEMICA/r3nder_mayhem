#!/bin/bash
echo "[*] Installing R3NDER OPS custom apps..."

TARGET_DIR=firmware/apps
MENU_FILE=firmware/menu_r3nder.cpp

mkdir -p $TARGET_DIR

for file in app_r3nder_*.cpp; do
    cp "$file" "$TARGET_DIR/"
    echo "Copied $file to $TARGET_DIR"
done

if [ ! -f $MENU_FILE ]; then
    echo "// Auto-generated R3NDER OPS menu" > $MENU_FILE
    echo '#include "app_r3nder_rfbeacon.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_rfjukebox.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_triggerradar.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_burstjammer.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_gpsfuzzer.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_microwavepresence.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_rfidnoise.cpp"' >> $MENU_FILE
    echo '#include "app_r3nder_rfmirror.cpp"' >> $MENU_FILE
    echo "" >> $MENU_FILE
    echo 'Menu r3nder_menu("R3NDER OPS");' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderRFBeacon());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderRFJukebox());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderTriggerRadar());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderBurstJammer());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderGPSFuzzer());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderMicrowavePresence());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderRFIDNoise());' >> $MENU_FILE
    echo 'r3nder_menu.add(new App_R3nderRFMirror());' >> $MENU_FILE
    echo 'main_menu.add(&r3nder_menu);' >> $MENU_FILE
    echo "Created $MENU_FILE"
fi

echo "[+] Done. Now rebuild your firmware with 'make -j4' from the firmware root."
